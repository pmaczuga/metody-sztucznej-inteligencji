import JSHOP2.*;
import java.util.*;

public class run{
	public static void main(String[] args) {
		//System.out.println(problem.getPlans());
        problem.getPlans();
		//new JSHOP2GUI();
	} 
}
