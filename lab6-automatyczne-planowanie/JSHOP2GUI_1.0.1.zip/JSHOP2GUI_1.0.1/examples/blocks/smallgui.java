import JSHOP2.*;
import java.util.*;

public class smallgui{
	public static void main(String[] args) {
		smallproblem.getPlans();
		new JSHOP2GUI();
	} 
}
