import JSHOP2.JSHOP2GUI;

public class gui{
	public static void main(String[] args) {
		System.out.println(problem.getPlans());
		new JSHOP2GUI();
	} 
}
